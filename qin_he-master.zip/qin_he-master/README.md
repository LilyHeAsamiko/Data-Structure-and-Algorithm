# Moi ja tervetuloa git-tietovarastoosi!

Hae heti ensimmäisenä ensimmäisen harjoitustyön koodit päivittämällä
tietovarastosi kurssin upstream-tietovarastosta. Ohjeet löytyvät kurssin
nettisivuilta (ja Moodlesta):
http://www.cs.tut.fi/~tiraka/fi/harjoitustyo_ymparisto.shtml#upstream

# Hello and welcome to your git repository!

Start your programming assignments by updating your repository to get
the code for the first programming assignment for course's
upstream repository. Instructions for doing that can be found on
course's web pages (and Moodle):
http://www.cs.tut.fi/~tiraka/en/harjoitustyo_ymparisto.shtml#upstream
