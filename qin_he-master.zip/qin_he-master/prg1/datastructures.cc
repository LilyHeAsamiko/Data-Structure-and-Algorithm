// Datastructures.cc

#include "datastructures.hh"
#include <vector>
#include <random>
#include <iostream>
#include <cmath>
#include <stack>
#include <algorithm>


std::minstd_rand rand_engine; // Reasonably quick pseudo-random generator

template <typename Type>
Type random_in_range(Type start, Type end)
{
    auto range = end-start;
    ++range;

    auto num = std::uniform_int_distribution<unsigned long int>(0, range-1)(rand_engine);

    return static_cast<Type>(start+num);
}

// Modify the code below to implement the functionality of the class.
// Also remove comments from the parameter names when you implement
// an operation (Commenting out parameter name prevents compiler from
// warning about unused parameters on operations you haven't yet implemented.)


Datastructures::Datastructures()
{
    Beaconlist = {};
    IDlist = {};
    int AdjSize = 100;
    for (int i = 0; i< AdjSize; i++)
    {
        std::vector<lightbeam> column;
        for (int j = 0; j< AdjSize; j++)
        {
            lightbeam l;
            //l.NoI = NULL;
            column.push_back(l);
        }
        Adj.push_back(column);
    }
}

Datastructures::~Datastructures()
{
    clear_beacons();
}


int Datastructures::beacon_count()
{
    // Replace this with your implementation
    return int(Beaconlist.size());
}


//void consRecur(Node *p)
//{
//    if (p->nxt) p->nxt->prv = p;
//    if (p->prv) p->prv->nxt = p;
//    consRecur(p->nxt);
//    consRecur(p->prv);
//}

//void connect(Node *p)
//{
//    p->nxt = NULL;
//    consRecur(p);
//}

//Node NewNode(Node *p)
//{
//    new Node *p;
//    p->nxt = NULL;
//    return *p;
//}

//void addEdge(Node *source, Node *target, AdjList adj)
//{
//    adj[target->No].push_back(* source);
//}


void Datastructures::clear_beacons()
{
    // Replace this with your implementation
    Beaconlist.erase(Beaconlist.begin(),Beaconlist.end());
}


std::vector<BeaconID> Datastructures::all_beacons()
{
    if (Beaconlist.empty()) return {NO_ID};
    // Replace this with your implementation
    return IDlist;
}

bool Datastructures::add_beacon(BeaconID id/*id*/, const std::string& name/*name*/, Coord xy/*xy*/, Color color/*color*/)
{
    // Replace this with your implementation
    auto ind = std::find(IDlist.begin(), IDlist.end(), id);
    unsigned int loc = ind-IDlist.begin();
    if(ind== IDlist.end())
    {
        double brightness=3*color.r+6*color.g+color.b;
        BeaconData p;
        p.NoI = loc;
        p.name = name;
        p.id = id;
        p.src = {NO_ID};
        p.tgt = NO_ID;
        p.xy = xy;
        p.dist = 0;
        p.color = color;
//        Beacon *beacon;
//        beacon->beaconData = p;
        Beaconlist.push_back(p);
        IDlist.push_back(id);
        return true;
    }
    return false;
}

std::string Datastructures::get_name(BeaconID id/*id*/)
{
    for(unsigned int i=0;i<Beaconlist.size();i++)
    {
        if(Beaconlist.at(i).id==id) return Beaconlist.at(i).name;
    }
    return NO_NAME;
}

Coord Datastructures::get_coordinates(BeaconID id/*id*/)
{
    // Replace; this with your implementation
    for(unsigned int i=0;i<Beaconlist.size();i++)
    {
        if(Beaconlist.at(i).id==id) return Beaconlist.at(i).xy;
    }
    return NO_COORD;
}

Color Datastructures::get_color(BeaconID id/*id*/)
{
    for(unsigned int i=0;i<Beaconlist.size();i++)
    {
        if(Beaconlist.at(i).id==id) return Beaconlist.at(i).color;
    }
    return NO_COLOR;
}

std::vector<BeaconID> Datastructures::beacons_alphabetically()
{
    std::sort(Beaconlist.begin(), Beaconlist.end(), [](BeaconData &p, BeaconData &q)
        {return p.name < q.name;});
    std::vector<std::vector<lightbeam>> temp;
    for(unsigned int i=0;i< Beaconlist.size();i++)
    {
//        unsigned int loc = Beaconlist.at(i).NoI;
        Beaconlist.at(i).NoI = i;
//        for (unsigned int j=0;j<Beaconlist.at(i).NoS.size();i++)
//        {
//            unsigned int locns;
//            temp[locns][i] = Adj[Beaconlist[i].NoS[j]][Beaconlist[i].NoI];
//        }
//        unsigned int locnt;
//        temp[locnt][i] = Adj[Beaconlist[i].NoT][Beaconlist[i].NoI];
        IDlist.push_back(Beaconlist.at(i).id);
    };
//    Adj = temp;
    return IDlist;
}

std::vector<BeaconID> Datastructures::beacons_brightness_increasing()
{
    std::sort(Beaconlist.begin(), Beaconlist.end(), [](BeaconData &p, BeaconData &q)
        {return p.brightness < q.brightness;});
    std::vector<std::vector<lightbeam>> temp;
    for(unsigned int i=0;i< Beaconlist.size();i++)
    {
//        unsigned int loc = Beaconlist.at(i).NoI;
        Beaconlist.at(i).NoI = i;
//        for (unsigned int j=0;j<Beaconlist.at(i).NoS.size();i++)
//        {

//            unsigned int locns;
//            temp[locns][i] = Adj[Beaconlist[i].NoS[j]][Beaconlist[i].NoI];
//        }
//        unsigned int locnt;
//        temp[locnt][i] = Adj[Beaconlist[i].NoT][Beaconlist[i].NoI];
        brightness_increasing.push_back(Beaconlist.at(i).id);
    };
//    Adj = temp;
    IDlist = brightness_increasing;
    return brightness_increasing;
}

BeaconID Datastructures::min_brightness()
{
    beacons_brightness_increasing();
    if (brightness_increasing.size()) return brightness_increasing[0];
    return NO_ID;
}

BeaconID Datastructures::max_brightness()
{
    beacons_brightness_increasing();
    if (brightness_increasing.size()) return brightness_increasing.at(brightness_increasing.size()-1);
    return NO_ID;
}

std::vector<BeaconID> Datastructures::find_beacons(std::string const& name/*name*/)
{
    // Replace this with your implementation
    std::vector<BeaconID> IDs;
    for(unsigned int i=0;i<Beaconlist.size();i++)
    {
        if(Beaconlist.at(i).name==name) IDs.push_back(Beaconlist.at(i).id);
    }
    if (IDs.begin() != IDs.end()) return IDs;
    else
        return {NO_ID};
}

bool Datastructures::change_beacon_name(BeaconID id/*id*/, const std::string& newname/*newname*/)
{
    // Replace this with your implementation
    for(unsigned int i=0;i<Beaconlist.size();i++)
    {
        if(Beaconlist.at(i).id==id)
        {
            Beaconlist.at(i).name = newname;
            return true;
        }
    }
    return false;
}

bool Datastructures::change_beacon_color(BeaconID id/*id*/, Color newcolor/*newcolor*/)
{
    for(unsigned int i=0;i<Beaconlist.size();i++)
    {
        if(Beaconlist.at(i).id==id)
        {
            Beaconlist.at(i).color = newcolor;
            return true;
        }
    }
    return false;
}

bool Datastructures::add_lightbeam(BeaconID sourceid/*sourceid*/, BeaconID targetid/*targetid*/)
{
    auto iters = std::find(IDlist.begin(),IDlist.end(), sourceid);
//    unsigned int loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
    unsigned int locs = static_cast<unsigned int>(iters-IDlist.begin());
    if (iters != IDlist.end())
    {
        lightbeam beamt;
//        Beacons->beaconData.tgt = targetid;
        auto itert = std::find(IDlist.begin(),IDlist.end(), targetid);
        unsigned int loct = static_cast<unsigned int>(itert-IDlist.begin());
        beamt.NoI= Beaconlist[loct].NoI;
        beamt.NoS.push_back(locs);
//        Beacon* Beacont = Adj[loct][loct];
        beamt.color.r = (Beaconlist[locs].color.r + Beaconlist[loct].color.r)/2;
        beamt.color.g = (Beaconlist[locs].color.g + Beaconlist[loct].color.g)/2;
        beamt.color.b = (Beaconlist[locs].color.b + Beaconlist[loct].color.b)/2;    //        Beacons->nxt = Beacont;
        beamt.dist = Beaconlist[locs].dist+1;
        Beaconlist[loct].dist = Beaconlist[locs].dist+1;
        Beaconlist[loct].NoS.push_back(locs);
        Beaconlist[loct].src.push_back(sourceid);
        Adj[loct][locs] = beamt;
//        Adj[loct][loct] = beamt;
        lightbeam beams;
        beams.NoI= Beaconlist[locs].NoI;
        beams.NoT= Beaconlist[loct].NoI;
        beams.dist = beamt.dist;
        Beaconlist[locs].tgt = targetid;
//        Beacon* Beacont = Adj[loct][loct];
        beams.color.r = (Beaconlist[locs].color.r + Beaconlist[loct].color.r)/2;
        beams.color.g = (Beaconlist[locs].color.g + Beaconlist[loct].color.g)/2;
        beams.color.b = (Beaconlist[locs].color.b + Beaconlist[loct].color.b)/2;    //        Beacons->nxt = Beacont;
        Adj[locs][loct] = beams;
//        Adj[locs][locs] = beams;
//        Adj[loct][locs] = Beacont;
        return true;
    }

    return false;
}

std::vector<BeaconID> Datastructures::get_lightsources(BeaconID id/*id*/)
{
    auto iter = std::find(IDlist.begin(),IDlist.end(), id);
    std::vector<BeaconID> IDs;
//    unsigned int loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
    unsigned int loc = static_cast<unsigned int>(iter-IDlist.begin());
    if (iter != IDlist.end())
    {
        for(unsigned int i=0; i< IDlist.size(); i++)
        {
            if( Adj[i][loc].NoT == Adj[loc][i].NoI)
                IDs.push_back(IDlist[i]);
        }
        return IDs;
    }
    return {NO_ID}; // Replace with actual implementation
}

std::vector<BeaconID> Datastructures::path_outbeam(BeaconID id/*id*/)
{
    std::vector<BeaconID> IDs;
    auto ind = std::find(IDlist.begin(), IDlist.end(), id);
//    //    unsigned int loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
    unsigned int loc = static_cast<unsigned int>(ind-IDlist.begin());
    if((ind == IDlist.end()) || Beaconlist.empty() ||Adj[loc].empty() ) return {NO_ID};
    unsigned int i = 0;
    while(i<Beaconlist.size())
    {
        if(Adj[loc][i].NoT == Adj[i][loc].NoI)
        {
            IDs.push_back(Beaconlist[loc].id);
            IDs.push_back(Beaconlist[loc].tgt);
            loc = i;
            i = 0;
        }
        else i++;

    }
    return IDs;
//    return {NO_ID};
}

bool Datastructures::remove_beacon(BeaconID id/*id*/)
{
    // Replace this with your implementation
    auto ind = std::find(IDlist.begin(),IDlist.end(), id);
//    unsigned int loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
    unsigned int loc = static_cast<unsigned int>(ind-IDlist.begin());
//    //    unsigned int count = IDlist_.size()-loc;
    if(ind != IDlist.end())
    {
        unsigned int s = Beaconlist.size();
        for (unsigned int i = loc; i<s; i++)
        {
            Beaconlist[loc]=Beaconlist[loc+1];
            IDlist[loc]=IDlist[loc+1];
            Adj[loc].erase(Adj[loc].begin(),Adj[loc].end());
            for(unsigned int j = 0; j<Beaconlist.size(); j++)
            {
                if(Adj[j][loc].NoT == Adj[loc][j].NoI) Adj[j].erase(Adj[j].begin()+loc);
            }
        }
        if(Beaconlist.size()==s)
            Beaconlist.erase(Beaconlist.begin()+s);
        return true;
    }
    return false;
}


std::vector<BeaconID> Datastructures::path_inbeam_longest(BeaconID id)
{
//     return {NO_ID};
    auto ind = std::find(IDlist.begin(), IDlist.end(), id);
//    unsigned int loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
    unsigned int loc = static_cast<unsigned int>(ind-IDlist.begin());
    if(ind == IDlist.end() || Beaconlist.empty() || Beaconlist[loc].dist == 0 ) return {NO_ID};
    std::vector<BeaconID> IDs;
    IDs.push_back(Beaconlist[loc].id);
    int d = Beaconlist [loc].dist;
    while((d != 0) && (loc != IDlist.size()))
    {
        for (unsigned int i = 0; i<Beaconlist[loc].NoS.size();i++)
        {
            if (Beaconlist[loc].NoS.size()==1)
            {
                loc = Beaconlist[loc].NoS[0];
                d = Beaconlist[loc].dist;
            }
            else if (Beaconlist[loc].NoS.size()>1)
            {
                if(Beaconlist[Beaconlist[loc].NoS[i]].dist < Beaconlist[Beaconlist[loc].NoS[i+1]].dist)
                {
                    d = Beaconlist[Beaconlist[loc].NoS[i+1]].dist;
                    loc = i+1;
                }
            }
            IDs.push_back(Beaconlist[loc].id);
        }


//        unsigned int count = Beaconlist[loc][loc]->No.size();
//        unsigned int lc = count;
//        while(count != 0)
//        {
//            if(Beaconlist[loc][Beaconlist[loc][loc]->No[lc]]->dist > Beaconlist[loc][Beaconlist[loc][loc]->No[count-1]]->dist)  lc = count-1;
//            count --;
//        }
//        d = Beaconlist[loc][Beaconlist[loc][loc]->No[lc]]->dist;
//        loc = Beaconlist[loc][loc]->No[lc];
    }    return IDs;
}

Color Datastructures::total_color(BeaconID id/*id*/)
{
    auto ind = std::find(IDlist.begin(),IDlist.end(), id);
    unsigned int loc = static_cast<unsigned int>(ind-IDlist.begin());
//    unsigned int loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
    if(ind == IDlist.end() || Beaconlist.empty()|| Adj[loc].empty() ) return {NO_COLOR};
    std::vector<BeaconID> IDs;
    Color totalcolor;
    totalcolor.r = Beaconlist[loc].color.r;
    totalcolor.g = Beaconlist[loc].color.g;
    totalcolor.b = Beaconlist[loc].color.b;
    int count = 1;
    while (!Beaconlist[loc].NoT)
    {
//        loc = static_cast<unsigned int>(std::distance(ind,IDlist.begin()));
        totalcolor.r += Beaconlist[Beaconlist[loc].NoT].color.r;
        totalcolor.g += Beaconlist[Beaconlist[loc].NoT].color.g;
        totalcolor.b += Beaconlist[Beaconlist[loc].NoT].color.b;
        loc = Beaconlist[loc].NoT;
        count++;
    }
    totalcolor.r /= count;
    totalcolor.g /= count;
    totalcolor.b /= count;
    return totalcolor;
}

//void Datastructure::quick_sort_name(std::<BeaconData*>& beaclonlist, int i, int j)
//{
//    BeaconData *tmp = beaconlist_.at((left+right)/2);
//    int i = left, j = right;
//    int pivot = tmp->name;
//    while(i<=j)
//    {
//        while(beaconlist_.at(i)->name < pivot) i++;
//        while(beaconlist_.at(j)->name > pivot) j--;
//        if (i <=j)
//        {
//            tmp = beaconlist_.at(i);
//            beaconlist_.at(i) = beaconlist_.at(j);
//            beaconlist_.at(i) =tmp;
//            i++;
//            j--;
//        }
//    }
//    if(left<j) quick_sort_name(beaconlist, left, j);
//    if(i<right) quick_sort_name(beaconlist, i, tight);
//}

//void Datastructure::quick_sort_brightness(std::<BeaconData*>& beaclonlist, int i, int j)
//{
//    BeaconData *tmp = beaconlist_.at((left+right)/2);
//    int i = left, j = right;
//    int pivot = tmp->brightness;
//    while(i<=j)
//    {
//        while(beaconlist_.at(i)->brightness < pivot) i++;
//        while(beaconlist_.at(j)->brightness > pivot) j--;
//        if (i <=j)
//        {
//            tmp = beaconlist_.at(i);
//            beaconlist_.at(i) = beaconlist_.at(j);
//            beaconlist_.at(i) =tmp;
//            i++;
//            j--;
//        }
//    }
//    if(left<j) quick_sort_brightnesse(beaconlist, left, j);
//    if(i<right) quick_sort_brightness(beaconlist, i, tight);
//}
