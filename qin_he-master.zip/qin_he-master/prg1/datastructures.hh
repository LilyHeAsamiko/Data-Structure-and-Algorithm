// Datastructures.hh

#ifndef DATASTRUCTURES_HH
#define DATASTRUCTURES_HH

#include <string>
#include <vector>
#include <utility>
#include <limits>
#include <stack>


// Type for beacon IDs
using BeaconID = std::string;
using BeaconName = std::string;

// Return value for cases where required beacon was not found
BeaconID const NO_ID = "----------";

// Return value for cases where integer values were not found
int const NO_VALUE = std::numeric_limits<int>::min();

// Return value for cases where name values were not found
std::string const NO_NAME = "-- unknown --";

// Type for a coordinate (x, y)
struct Coord
{
    int x = NO_VALUE;
    int y = NO_VALUE;
};

// Example: Defining == and hash function for Coord so that it can be used
// as key for std::unordered_map/set, if needed
inline bool operator==(Coord c1, Coord c2) { return c1.x == c2.x && c1.y == c2.y; }
inline bool operator!=(Coord c1, Coord c2) { return !(c1==c2); } // Not strictly necessary

struct CoordHash
{
    std::size_t operator()(Coord xy) const
    {
        auto hasher = std::hash<int>();
        auto xhash = hasher(xy.x);
        auto yhash = hasher(xy.y);
        // Combine hash values (magic!)
        return xhash ^ (yhash + 0x9e3779b9 + (xhash << 6) + (xhash >> 2));
    }
};


// Example: Defining < for Coord so that it can be used
// as key for std::map/set
inline bool operator<(Coord c1, Coord c2)
{
    if (c1.y < c2.y) { return true; }
    else if (c2.y < c1.y) { return false; }
    else { return c1.x < c2.x; }
}

// Return value for cases where coordinates were not found
Coord const NO_COORD = {NO_VALUE, NO_VALUE};

// Type for color (RGB)
struct Color
{
    int r = NO_VALUE;
    int g = NO_VALUE;
    int b = NO_VALUE;
};

struct lightbeam
{
    std::vector<unsigned int> NoS;
    unsigned int NoI;
    unsigned int NoT;
    int dist;
    Color color;
};

struct BeaconData
{
    std::vector<unsigned int> NoS;
    unsigned int NoI;
    unsigned int NoT;
    std::string name;
    std::vector<BeaconID> src;
    BeaconID id;
    Coord xy;
    Color color;
    double brightness;
    int dist;
    BeaconID tgt;
};

//class Beacon
//{
//public:
//    BeaconData beaconData;

//    Beacon* nxt;
//    Beacon(unsigned int nos, unsigned int noi, unsigned int not, std::string name, Coord xy, Color color, double brightness, int dist, BeaconID tgt,BeaconID src,BeaconID id, Beacon *nxt)
//    {
//        this->beaconData.NoS.push_back(nos);
//        this->beaconData.NoI = noi;
//        this->beaconData.NoT = not;
//        this->beaconData.name = name;
//        this->beaconData.src = src;
//        this->beaconData.id = id;
//        this->beaconData.xy = xy;
//        this->beaconData.color = color;
//        this->beaconData.dist = dist;
//        this->beaconData.tgt = tgt;
//        this->beaconData.brightness = brightness;

//        this->nxt = nxt;
//    }
//};

// Equality and non-equality comparisons for Colors
inline bool operator==(Color c1, Color c2) { return c1.r == c2.r && c1.g == c2.g && c1.b == c2.b; }
inline bool operator!=(Color c1, Color c2) { return !(c1==c2); }

// Return value for cases where color was not found
Color const NO_COLOR = {NO_VALUE, NO_VALUE, NO_VALUE};

// Type for light transmission cost (used only in the second assignment)
using Cost = int;

// Return value for cases where cost is unknown
Cost const NO_COST = NO_VALUE;


// This is the class you are supposed to implement

class Datastructures
{
public:
    Datastructures();
    ~Datastructures();

    // Estimate of perform  ance:O(n)
    // Short rationale for estimate: It is a linear computation. Returning the size of the beaconlist only.
    int beacon_count();

    // Estimate of performance:O(n)
    // Short rationale for estimate: Similar as the beacon count, it simply go over the whole beaconlist.
    void clear_beacons();

    // Estimate of performance: O(n)
    // Short rationale for estimate: Again, similar as the clear_beacons, it simply go ovrf the whole beaconlist and return the id.
    std::vector<BeaconID> all_beacons();

    // Estimate of performance: O(1)
    // Short rationale for estimate: It is a constant computation. Only to push the new beacon without any sorting or inserting.
    bool add_beacon(BeaconID id, std::string const& name, Coord xy, Color color);

    // Estimate of performance: O(n)
    // Short rationale for estimate:It is based on find beacons with one more operation return the name.
    std::string get_name(BeaconID id);

    // Estimate of performance: O(n)
    // Short rationale for estimate:It is based on find beacons with one more operation return the coordinate.
    Coord get_coordinates(BeaconID id);

    // Estimate of performance:O(n)
    // Short rationale for estimate:Similar as get_name and coordinate, it is based on find beacons with one more operation return the color.
    Color get_color(BeaconID id);

    // We recommend you implement the operations below only after implementing the ones above

    // Estimate of performance:O(nlog(n))
    // Short rationale for estimate: If the memory is enough, the For the sorting part,the complexity is linear computation and thus the time complexity is O(nlog(n)) while
    // if the memory is not enough,it will become worse which is O(nlog²(n)).
    std::vector<BeaconID> beacons_alphabetically();

    // Estimate of performance:O(nlog(n))
    // Short rationale for estimate: Similar as the sort on name alphabeticaloly. Only difference is adding the compaire by brightness which is beased on color instead of the name.
    //Thus the complexity of the average case is O(nlog(n)) if memory is enough while as worse as O(nlog²(n)) when memory is not enough.
    std::vector<BeaconID> beacons_brightness_increasing();

    // Estimate of performance:O(1)
    // Short rationale for estimate: Search  of elements have average constant-time complexity. Incrementing an iterator is constant time so after sort already, the complexity of pure
    // getting the min_brightness which is the first elements will be O(1)
    BeaconID min_brightness();

    // Estimate of performance:O(1)
    // Short rationale for estimate: Search of elements have average constant-time complexity. Incrementing an iterator is constant time so after sort already, the complexity of pure
    // getting the min_brightness which is the largest elements will be O(n)
    BeaconID max_brightness();

    // Estimate of performance:O(n)
    // Short rationale for estimate: Consider the search on general case which is implemented on unsorted list,the average complesity will be theta(n) while the best performance will
    // be theta(1) if the beacon is found at the first one. In the worst case, no common elements in the arrays or the last elements are the same making the performance to be theta(n²).
    std::vector<BeaconID> find_beacons(std::string const& name);

    // Estimate of performance:O(n)
    // Short rationale for estimate: It is based on find_beacons, but with one more step to change the name into new one. Thus, complexity is theta(n)*theta(1) which is still theta(n).
    bool change_beacon_name(BeaconID id, std::string const& newname);

    // Estimate of performance:O(n)
    // Short rationale for estimate: Basically the same as change_beacon_name,changing the operation as chaging the color. Thus, the complexity is still theta(n).
    bool change_beacon_color(BeaconID id, Color newcolor);

    // We recommend you implement the operations below only after implementing the ones above

    // Estimate of performance O(n)
    // Short rationale for estimate: In our case, we use the adjacency matrix for graphs.
    // It searches n times averagely on the adj according to source id and target id and store the beam at Adj[source location][target location] which let  the find source in other function to be easy.
    bool add_lightbeam(BeaconID sourceid, BeaconID targetid);

    // Estimate of performance: O(n)
    // Short rationale for estimate:Similar as get_name and coordinate, it is based on find beacons but searching the edges by row and acoording to the colume get the source.
    std::vector<BeaconID> get_lightsources(BeaconID id);

    // Estimate of performance: O(n)
    // Short rationale for estimate: In my case, I use the adjacency matrix structure for graphs.
    // It is then the same as the search in the row only and with non-zero dist, according to colume goes to the next row and finally return the target id everytime.
    std::vector<BeaconID> path_outbeam(BeaconID id);

    // Non-compulsory operations

    // Estimate of performance:Theta(n)
    // Short rationale for estimate:Similar as get_name and coordinate, move the one after the required andfree the last space. It is based on find beacons with operation giving next beacon to the current space and delete the last one space.
    bool remove_beacon(BeaconID id);

    // Estimate of performance: O(n)
    // Short rationale for estimate: It is first the same as the search in the adjmatix and return the source id everytime then neads to go through the upper beams constant times to
    // choose the parent beacon with largest dist and return the longest beam id.
    std::vector<BeaconID> path_inbeam_longest(BeaconID id);

    // Estimate of performance: O(n)
    // Short rationale for estimate:Similar as get_color, but with searching on the adjList and do sum of the color everytime.
    Color total_color(BeaconID id);

//    void consRecur(Graph *G);

private:
//    void quick_sort_name(std::vector<BeaconData*>& beaconlist, int left, int right);
//    void quick_sort_brightness(std::vector<BeaconData*>& beaconlist, int left, int right);
    // Add stuff needed for your class implementation here
//    std::vector <BeaconName> namelist_;
    std::vector<BeaconID> brightness_increasing;
//    std::pair<BeaconID, BeaconData*> beaconlist_p;
    std::vector<BeaconID> IDlist;
//    std::vector<vector<BeaconID>> adjList;
    std::vector<BeaconData> Beaconlist;
    std::vector<std::vector<lightbeam>> Adj;
//    std::vector<std::vector<int>> Adj;
};

#endif // DATASTRUCTURES_HH
